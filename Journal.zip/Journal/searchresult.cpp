#include "searchresult.h"
#include "ui_searchresult.h"
#include "mainwindow.h"
#include "myspace.h"
#include "journalitem.h"

#include <QMessageBox>
#include <QLineEdit>
#include <QDir>

SearchResult::SearchResult(QString search_input, MainWindow *home, QWidget *parent):
    QWidget(parent),
    ui(new Ui::SearchResult),
    home_page(home),
    target(search_input)
{
    ui->setupUi(this);
    this->setWindowTitle(QString("\"%1\"的搜索结果").arg(search_input));
    setBackground();
    setButtonIcon();
    showProfilePhoto();

    connect(ui->searchInput, &QLineEdit::returnPressed, this, &SearchResult::search);

    QTextCursor cursor = ui->userName->textCursor();
    QTextBlockFormat blockFormat;
    blockFormat.setAlignment(Qt::AlignCenter);
    cursor.setBlockFormat(blockFormat);
    cursor.insertText(QString::fromStdString(home_page->user_name));
    ui->userName->setTextCursor(cursor);

    showResult();
}

SearchResult::~SearchResult()
{
    delete ui;
}

void SearchResult::showProfilePhoto()
{
    QGraphicsScene *scene = new QGraphicsScene;
    QPixmap pix;
    pix.load(QString::fromStdString(home_page->path+"profile_photos/"+home_page->user_name+".jpg"));
    scene->addPixmap(pix.scaled(200, 200));
    ui->ProfilePhoto->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->ProfilePhoto->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->ProfilePhoto->setScene(scene);
    ui->ProfilePhoto->show();
}

void SearchResult::setBackground()
{
    QPalette pa(this->palette());
    QImage background = QImage(":/background/background.png");
    background = background.scaled(this->size());
    QBrush* bg = new QBrush(background);
    pa.setBrush(QPalette::Window, * bg);
    this->setPalette(pa);
}

void SearchResult::setButtonIcon()
{
    QIcon icon1, icon2;

    icon1.addFile(":/icon/icon1.png");
    ui->searchButton->setIcon(icon1);

    icon2.addFile(":/icon/icon4.png");
    ui->backButton->setIcon(icon2);
    ui->backButton->setIconSize(QSize(110, 110));
}

void SearchResult::on_backButton_clicked()
{
    emit backSignal();
    this->deleteLater();
}

void SearchResult::on_searchButton_clicked()
{
    search();
}

void SearchResult::search()
{
    QString search_text = ui->searchInput->text();
    if (search_text.isEmpty())
        QMessageBox::warning(this, "提示", "搜索内容不能为空！");
    else
    {
        SearchResult *result_widget = new SearchResult(search_text, this->home_page);
        connect(result_widget, &SearchResult::backSignal, this->home_page, &MainWindow::show);
        result_widget->show();
        ui->searchInput->clear();
        this->deleteLater();
    }
}

void SearchResult::on_spaceButton_clicked()
{
    MySpace *ms = new MySpace(this->home_page);
    ms->show();
    this->deleteLater();
}

void SearchResult::showResult()
{
    QListWidgetItem *item;
    JournalItem *journal;
    QDir dir(QString::fromStdString(home_page->path+"journals"));
    QFileInfoList list = dir.entryInfoList(QDir::NoDotAndDotDot | QDir::AllEntries);
    int cnt = 0;
    while ((pos <= list.size()) && (cnt < 4))
    {
        QFile file(list.at(list.size()-pos).filePath());
        file.open(QIODevice::ReadOnly | QIODevice::Text);
        std::string file_name = list.at(list.size()-pos).fileName().toStdString();
        QString content = file.readAll();
        bool flag = false;
        for (int i=0; i<content.size()-target.size()-1; i++)
        {
            if (content.mid(i, target.size()) == target)
                flag = true;
        }
        if (flag)
        {
            item = new QListWidgetItem;
            journal = new JournalItem(this);
            item->setSizeHint(QSize(0, 300));
            journal->setText(content);
            journal->setProfile(home_page->path, file_name.substr(14, file_name.size()-18));
            journal->setDate(QString::fromStdString(file_name.substr(0, 10)));
            ui->listWidget->addItem(item);
            ui->listWidget->setItemWidget(item, journal);
            cnt ++;
        }
        pos ++;
    }
}
