#ifndef REGISTERPAGE_H
#define REGISTERPAGE_H

#include <QDialog>
#include <loginpage.h>
#include <setup.h>

namespace Ui {
class RegisterPage;
}

class RegisterPage : public QDialog
{
    Q_OBJECT

public:
    explicit RegisterPage(QWidget *parent = nullptr);
    ~RegisterPage();
    LoginPage * & getreturnpage(){
        return returnpage;
    }

private slots:
    void on_Register_clicked();

private:
    Ui::RegisterPage *ui;
    LoginPage * returnpage;
};

#endif // REGISTERPAGE_H
