#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "setup.h"

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(std::string user, QWidget *parent = nullptr);
    ~MainWindow();
    std::string path;
    std::string user_name;

private slots:
    void onReachedBottom();
    void on_searchButton_clicked();
    void on_createButton_clicked();
    void on_spaceButton_clicked();

    void on_refreshButton_clicked();

private:
    Ui::MainWindow *ui;
    int pos = 1;
    void setBackground();
    void setButtonIcon();
    void showProfilePhoto();
    void search();
    void showJournals();
};
#endif // MAINWINDOW_H
