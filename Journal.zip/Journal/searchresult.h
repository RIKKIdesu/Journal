#ifndef SEARCHRESULT_H
#define SEARCHRESULT_H

#include "mainwindow.h"

#include <QMainWindow>
#include <QWidget>

namespace Ui {
class SearchResult;
}

class SearchResult : public QWidget
{
    Q_OBJECT

public:
    explicit SearchResult(QString search_input, MainWindow *home, QWidget *parent = nullptr);
    ~SearchResult();

private slots:
    void on_backButton_clicked();

    void on_searchButton_clicked();

    void on_spaceButton_clicked();

signals:
    void backSignal();

private:
    Ui::SearchResult *ui;
    MainWindow *home_page;
    QString target;
    int pos = 1;
    void setBackground();
    void setButtonIcon();
    void showProfilePhoto();
    void search();
    void showResult();
};

#endif // SEARCHRESULT_H
