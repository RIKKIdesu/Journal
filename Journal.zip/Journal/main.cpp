#include "mainwindow.h"
#include "loginpage.h"
#include "setup.h"

#include <QApplication>
#include <fstream>

void loading()
{
    std::ifstream fd("Journal.dat");
    if(fd.fail())
    {
        std::ofstream outfile("Journal.dat");
        outfile << "users.txt\n1\n";
        outfile.close();
    }
    fd >> setup::DataFilePath;
    fd >> setup::FormStyle;
    return;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    loading();
    LoginPage *w = new LoginPage;
    w->setWindowTitle("登录Journal");
    w->show();
    // w.setMaximumSize(1500, 900);
    // w.setMinimumSize(1500, 900);
    // w.setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowTitleHint | Qt::WindowMinimizeButtonHint | Qt::WindowCloseButtonHint);
    // w.setWindowTitle("Journal");
    // w.show();
    return a.exec();
}
