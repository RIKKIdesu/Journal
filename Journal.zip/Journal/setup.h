#ifndef SETUP_H
#define SETUP_H

#include <QDialog>
#include <loginpage.h>

namespace Ui {
class setup;
}

class setup : public QDialog
{
    Q_OBJECT

public:
    explicit setup(QWidget *parent = nullptr);
    ~setup();
    LoginPage * & getreturnpage(){
        return returnpage;
    }
    static std::string DataFilePath;
    static int FormStyle;

private slots:
    void on_SelectFile_clicked();

    void on_loadData_clicked();

private:
    Ui::setup *ui;
    LoginPage * returnpage;
};

#endif // SETUP_H
