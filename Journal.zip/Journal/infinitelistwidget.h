#ifndef INFINITELISTWIDGET_H
#define INFINITELISTWIDGET_H

#include <QListWidget>
#include <QScrollBar>

class InfiniteListWidget: public QListWidget
{
    Q_OBJECT

public:
    InfiniteListWidget(QWidget *parent = nullptr);
    ~InfiniteListWidget();

signals:
     void sliderChange(int p);
     void reachBottom();

private slots:
     void onSliderChanged(int p);

private :
     QScrollBar *scroll_bar;
};

#endif // INFINITELISTWIDGET_H
