#include "infinitelistwidget.h"

InfiniteListWidget::InfiniteListWidget(QWidget *parent): QListWidget(parent)
{
    scroll_bar = verticalScrollBar();
    connect(scroll_bar, &QScrollBar::valueChanged, this, &InfiniteListWidget::onSliderChanged);
}

InfiniteListWidget::~InfiniteListWidget() {}

void InfiniteListWidget::onSliderChanged(int p)
{
    if (p == scroll_bar->maximum())
        emit reachBottom();
    emit sliderChange(p);
}
