#ifndef FORGETPASSWORDPAGE_H
#define FORGETPASSWORDPAGE_H

#include <QDialog>
#include <loginpage.h>
#include <setup.h>

namespace Ui {
class ForgetPasswordPage;
}

class ForgetPasswordPage : public QDialog
{
    Q_OBJECT

public:
    explicit ForgetPasswordPage(QWidget *parent = nullptr);
    ~ForgetPasswordPage();
    LoginPage * & getreturnpage(){
        return returnpage;
    }

private slots:
    void on_FindUsername_clicked();

private:
    Ui::ForgetPasswordPage *ui;
    LoginPage * returnpage;
};

#endif // FORGETPASSWORDPAGE_H
