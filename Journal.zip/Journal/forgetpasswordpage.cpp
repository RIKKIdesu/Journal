#include "forgetpasswordpage.h"
#include "ui_forgetpasswordpage.h"
#include <QMessageBox>
#include <qstring.h>
#include <iostream>
#include <unistd.h>
#include <fstream>
#include <setup.h>
#include <loginpage.h>

ForgetPasswordPage::ForgetPasswordPage(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ForgetPasswordPage)
{
    ui->setupUi(this);
    ui->centralwidget->setStyleSheet("#centralwidget{border-image:url(:/new/prefix1/bg.png)}");
}

ForgetPasswordPage::~ForgetPasswordPage()
{
    delete ui;
}

void ForgetPasswordPage::on_FindUsername_clicked()
{
    QString Username = ui->UsernameLine->text();
    if(Username == QString()){
        QMessageBox::information(this,tr("出错啦!"),"请输入用户名!");
        return;
    }
    std::string name=Username.toStdString(), s_name, s_pass;
    //查找用户名
    std::ifstream f2(setup::DataFilePath);
    if(f2.fail()){
        std::ofstream outfile(setup::DataFilePath);
        outfile << "USERS:" << " " << "PASSWORDS:" <<std::endl;
        outfile.close();
    }
    while(f2>>s_name>>s_pass){
        if (s_name==name){
            QString text=QString::fromStdString("您的密码是:"+s_pass);
            QMessageBox::information(this,tr("查询成功!"),text);
            return;
        }
    }
    QMessageBox::information(this,tr("查询失败!"),QString("没有找到该用户!"));
    return;
}

