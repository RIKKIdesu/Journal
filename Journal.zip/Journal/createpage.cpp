#include "createpage.h"
#include "ui_createpage.h"
#include "myspace.h"

#include <QFontComboBox>
#include <QMessageBox>
#include <QFile>

void (QSpinBox::*spinBoxSignal)(int) = &QSpinBox::valueChanged;

CreatePage::CreatePage(MainWindow *home, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CreatePage),
    home_page(home)
{
    ui->setupUi(this);
    this->setWindowTitle("新建日记");

    setButtonIcon();
    setBackground();
    showProfilePhoto();
    setTextEdit();

    QTextCursor cursor = ui->userName->textCursor();
    QTextBlockFormat blockFormat;
    blockFormat.setAlignment(Qt::AlignCenter);
    cursor.setBlockFormat(blockFormat);
    cursor.insertText(QString::fromStdString(home_page->user_name));
    ui->userName->setTextCursor(cursor);
}

CreatePage::~CreatePage()
{
    delete ui;
}

void CreatePage::showProfilePhoto()
{
    QGraphicsScene *scene = new QGraphicsScene;
    QPixmap pix;
    pix.load(QString::fromStdString(home_page->path+"profile_photos/"+home_page->user_name+".jpg"));
    scene->addPixmap(pix.scaled(200, 200));
    ui->ProfilePhoto->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->ProfilePhoto->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->ProfilePhoto->setScene(scene);
    ui->ProfilePhoto->show();
}

void CreatePage::setBackground()
{
    QPalette pa(this->palette());
    QImage background = QImage(":/background/background.png");
    background = background.scaled(this->size());
    QBrush* bg = new QBrush(background);
    pa.setBrush(QPalette::Window, * bg);
    this->setPalette(pa);
}

void CreatePage::on_backButton_clicked()
{
    home_page->show();
    this->deleteLater();
}

void CreatePage::setButtonIcon()
{
    QIcon icon;

    icon.addFile(":/icon/icon4.png");
    ui->backButton->setIcon(icon);
    ui->backButton->setIconSize(QSize(110, 110));
}

void CreatePage::setFont(QFont f)
{
    int size = ui->textEdit->font().pointSize();
    f.setPointSize(size);
    ui->textEdit->setFont(f);
}

void CreatePage::setSize(int size)
{
    QFont f = ui->textEdit->font();
    f.setPointSize(size);
    ui->textEdit->setFont(f);
}

void CreatePage::setTextEdit()
{
    ui->dateEdit->setDateTime(QDateTime::currentDateTime());

    ui->fontComboBox->setCurrentFont(QFont("楷体"));
    connect(ui->fontComboBox, &QFontComboBox::currentFontChanged, this, &CreatePage::setFont);

    ui->spinBox->setValue(12);
    ui->spinBox->setMinimum(8);
    ui->spinBox->setMaximum(30);
    connect(ui->spinBox, static_cast<void(QSpinBox::*)(int)>(&QSpinBox::valueChanged), this, &CreatePage::setSize);

    ui->textEdit->setFont(QFont("楷体", 12));
    ui->textEdit->setText("记录每一天~");
}

void CreatePage::on_spaceButton_clicked()
{
    int choice = QMessageBox::information(this, "提示", "您做的修改还未保存，是否保存为草稿？", "是", "否", "取消");
    switch (choice)
    {
        case 2:
            return;
        case 0:
        default:
            MySpace *ms = new MySpace(this->home_page);
            ms->show();
            this->deleteLater();
    }
}

void CreatePage::on_publishButton_clicked()
{
    QString content = ui->textEdit->toPlainText();
    if (content == QString())
    {
        QMessageBox::information(this, "提示", "日记内容不能为空！");
        return;
    }
    QString date = ui->dateEdit->date().toString("yyyy-MM-dd-01-");
    QFile file(QString::fromStdString(home_page->path+"journals/"+date.toStdString()+home_page->user_name+".txt"));
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    file.write(content.toUtf8());
    QMessageBox::information(NULL, "提示", "发表成功！");
    ui->textEdit->clear();
}
