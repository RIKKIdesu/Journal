#ifndef MYSPACE_H
#define MYSPACE_H

#include "mainwindow.h"

#include <QMainWindow>
#include <QWidget>

namespace Ui {
class MySpace;
}

class MySpace : public QWidget
{
    Q_OBJECT

public:
    explicit MySpace(MainWindow *home, QWidget *parent = nullptr);
    ~MySpace();

private slots:
    void on_backButton_clicked();

private:
    Ui::MySpace *ui;
    MainWindow *home_page;
    int pos = 1;
    void setBackground();
    void setButtonIcon();
    void showProfilePhoto();
    void showJournals();
};

#endif // MYSPACE_H
