#include "journalitem.h"
#include "ui_journalitem.h"

JournalItem::JournalItem(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::JournalItem)
{
    ui->setupUi(this);
    this->setWindowFlag(Qt::FramelessWindowHint);
}

JournalItem::~JournalItem()
{
    delete ui;
}

void JournalItem::setText(QString content)
{
    ui->journalText->setText(content);
}

void JournalItem::setProfile(std::string path, std::string user_name)
{
    ui->userName->setText(QString::fromStdString(user_name));
    QGraphicsScene *scene = new QGraphicsScene;
    QPixmap pix;
    pix.load(QString::fromStdString(path+"profile_photos/"+user_name+".jpg"));
    scene->addPixmap(pix.scaled(40, 40));
    ui->profilePhoto->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->profilePhoto->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->profilePhoto->setScene(scene);
    ui->profilePhoto->show();
}

void JournalItem::setDate(QString date)
{
    ui->date->setText(date);
}
