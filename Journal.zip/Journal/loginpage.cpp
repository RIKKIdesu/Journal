#include "loginpage.h"
#include "ui_loginpage.h"
#include <forgetpasswordpage.h>
#include <registerpage.h>
#include <QMessageBox>
#include <qstring.h>
#include <iostream>
#include <unistd.h>
#include <fstream>
#include <setup.h>
#include <QStyle>

#include "mainwindow.h"

LoginPage::LoginPage(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LoginPage)
{
    ui->setupUi(this);
    ui->centralwidget->setStyleSheet("#centralwidget{border-image:url(:/new/prefix1/bg.png)}");

}

LoginPage::~LoginPage()
{
    delete ui;
}

void LoginPage::on_ForgetPassword_clicked()
{
    this->hide();
    ForgetPasswordPage f;
    f.getreturnpage() = this;
    f.setWindowTitle(QString("找回密码"));
    f.show();
    int result=f.exec();
    if(result == QDialog::Accepted){
        f.hide();
        this->show();
        return;
    }
    if(result == QDialog::Rejected){
        f.close();
        this->close();
    }
    return;
}


void LoginPage::on_Register_clicked()
{
    this->hide();
    RegisterPage r;
    r.getreturnpage() = this;
    r.setWindowTitle(QString("注册账户"));
    r.show();
    int result=r.exec();
    if(result == QDialog::Accepted){
        r.hide();
        this->show();
        return;
    }
    if(result == QDialog::Rejected){
        r.close();
        this->close();
    }
    return;
}


void LoginPage::on_LoginButton_clicked()
{
    std::string file = setup::DataFilePath + "/users.txt";
    QString Username = ui->UsernameLine->text();
    QString Password = ui->PasswordLine->text();
    std::string name=Username.toStdString(), pass=Password.toStdString(), s_name, s_pass;
    //查找账户
    std::ifstream f2(file);
    if(f2.fail()){
        std::ofstream outfile(file);
        outfile << "USERS:" << " " << "PASSWORDS:" <<std::endl;
        outfile.close();
    }
    while(f2>>s_name>>s_pass){
        if (s_name == name){
            if (s_pass == pass){
                ui->LoginButton->setText("登录中...");
                ui->LoginButton->repaint();
                sleep(1);
                ui->LoginButton->setText("登录成功!");
                ui->LoginButton->repaint();
                sleep(1);

                MainWindow *w = new MainWindow(s_name);
                w->setMaximumSize(1500, 900);
                w->setMinimumSize(1500, 900);
                w->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowTitleHint | Qt::WindowMinimizeButtonHint | Qt::WindowCloseButtonHint);
                w->setWindowTitle("Journal");
                w->show();

                this->deleteLater();
                return;
            }
        }
    }
    QMessageBox::information(this,tr("登录失败!"),"用户名或密码错误!");
    return;
}

void LoginPage::on_Setup_clicked()
{
    this->hide();
    setup s;
    s.getreturnpage() = this;
    s.setWindowTitle(QString("设置"));
    s.show();
    int result=s.exec();
    if(result == QDialog::Accepted){
        s.hide();
        this->show();
        return;
    }
    if(result == QDialog::Rejected){
        s.close();
        this->close();
    }
    return;
}

