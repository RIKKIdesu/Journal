#include "setup.h"
#include "ui_setup.h"
#include <QFileDialog>
#include <loginpage.h>
#include <fstream>

std::string setup::DataFilePath = "C:/Users/Lee/Desktop";
int setup::FormStyle = 1;

setup::setup(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::setup)
{
    ui->setupUi(this);
    ui->centralwidget->setStyleSheet("#centralwidget{border-image:url(:/new/prefix1/bg.png)}");
    ui->Filename->setText(QString().fromStdString("C:/Users/Lee/Desktop"));

    DataFilePath = "C:/Users/Lee/Desktop";
}

setup::~setup()
{
    delete ui;
}

void setup::on_SelectFile_clicked()
{
    QString path_name = QFileDialog::getExistingDirectory(this, "保存路径", "C:/Users/Lee/Desktop");
    if(path_name == QString())
        return;
    ui->Filename->setText(path_name);
    std::ofstream outfile("Journal.dat");
    outfile << path_name.toStdString() << std::endl << setup::FormStyle << std::endl;
    outfile.close();
    setup::DataFilePath = path_name.toStdString();
    return;
}


void setup::on_loadData_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this,"打开文本文件","C:/",".txt");
    if(filename == QString())
        return;
}

