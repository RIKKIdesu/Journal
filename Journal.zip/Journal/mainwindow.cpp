#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "infinitelistwidget.h"
#include "searchresult.h"
#include "createpage.h"
#include "myspace.h"
#include "journalitem.h"
#include "setup.h"

#include <QThread>
#include <QMessageBox>
#include <QDir>
#include <QTextStream>

MainWindow::MainWindow(std::string user, QWidget *parent):
    QMainWindow(parent),
    user_name(user),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    path = setup::DataFilePath + "/";
    QDir *dir = new QDir;
    dir->mkdir(QString::fromStdString(path+"profile_photos"));
    dir->mkdir(QString::fromStdString(path+"journals"));

    setBackground();
    setButtonIcon();
    showProfilePhoto();

    showJournals();

    connect(ui->listWidget, &InfiniteListWidget::reachBottom, this, &MainWindow::onReachedBottom);
    connect(ui->searchInput, &QLineEdit::returnPressed, this, &MainWindow::search);

    QTextCursor cursor = ui->userName->textCursor();
    QTextBlockFormat blockFormat;
    blockFormat.setAlignment(Qt::AlignCenter);
    cursor.setBlockFormat(blockFormat);
    cursor.insertText(QString::fromStdString(user_name));
    ui->userName->setTextCursor(cursor);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showProfilePhoto()
{
    QGraphicsScene *scene = new QGraphicsScene;
    QPixmap pix;
    pix.load(QString::fromStdString(path+"profile_photos/"+user_name+".jpg"));
    scene->addPixmap(pix.scaled(200, 200));
    ui->ProfilePhoto->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->ProfilePhoto->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->ProfilePhoto->setScene(scene);
    ui->ProfilePhoto->show();
}

void MainWindow::setBackground()
{
    QPalette pa(this->palette());
    QImage background = QImage(":/background/background.png");
    background = background.scaled(this->size());
    QBrush* bg = new QBrush(background);
    pa.setBrush(QPalette::Window, * bg);
    this->setPalette(pa);
}

void MainWindow::setButtonIcon()
{
    QIcon icon1, icon2, icon3;

    icon1.addFile(":/icon/icon1.png");
    ui->searchButton->setIcon(icon1);

    icon2.addFile(":/icon/icon2.png");
    ui->createButton->setIcon(icon2);
    ui->createButton->setIconSize(QSize(110, 110));

    icon3.addFile(":/icon/icon5.png");
    ui->refreshButton->setIcon(icon3);
    ui->refreshButton->setIconSize(QSize(110, 110));
}

void MainWindow::onReachedBottom()
{
    QListWidgetItem *item;
    JournalItem *journal;

    QDir dir(QString::fromStdString(path+"journals"));
    QFileInfoList list = dir.entryInfoList(QDir::NoDotAndDotDot | QDir::AllEntries);
    int cnt = 0;
    while ((pos <= list.size()) && (cnt < 3))
    {
        item = new QListWidgetItem();
        journal = new JournalItem(this);
        item->setSizeHint(QSize(0, 300));
        QFile file(list.at(list.size()-pos).filePath());
        file.open(QIODevice::ReadOnly | QIODevice::Text);
        QString content = file.readAll();
        journal->setText(content);
        std::string file_name = list.at(list.size()-pos).fileName().toStdString();
        journal->setProfile(path, file_name.substr(14, file_name.size()-18));
        journal->setDate(QString::fromStdString(file_name.substr(0, 10)));
        ui->listWidget->addItem(item);
        ui->listWidget->setItemWidget(item, journal);
        pos ++;
        cnt ++;
    }
}

void MainWindow::on_searchButton_clicked()
{
    search();
}

void MainWindow::on_createButton_clicked()
{
    CreatePage *create_page = new CreatePage(this);
    create_page->show();
    this->hide();
}

void MainWindow::search()
{
    QString search_text = ui->searchInput->text();
    if (search_text.isEmpty())
        QMessageBox::warning(this, "提示", "搜索内容不能为空！");
    else
    {
        SearchResult *result_widget = new SearchResult(search_text, this);
        connect(result_widget, &SearchResult::backSignal, this, &MainWindow::show);
        result_widget->show();
        ui->searchInput->clear();
        this->hide();
    }
}

void MainWindow::on_spaceButton_clicked()
{
    MySpace *ms = new MySpace(this);
    ms->show();
    this->hide();
}

void MainWindow::showJournals()
{
    QListWidgetItem *item;
    JournalItem *journal;
    QDir dir(QString::fromStdString(path+"journals"));
    QFileInfoList list = dir.entryInfoList(QDir::NoDotAndDotDot | QDir::AllEntries);
    while ((pos <= list.size()) && (pos < 4))
    {
        item = new QListWidgetItem();
        journal = new JournalItem(this);
        item->setSizeHint(QSize(0, 300));
        QFile file(list.at(list.size()-pos).filePath());
        file.open(QIODevice::ReadOnly | QIODevice::Text);
        QString content = file.readAll();
        journal->setText(content);
        std::string file_name = list.at(list.size()-pos).fileName().toStdString();
        journal->setProfile(path, file_name.substr(14, file_name.size()-18));
        journal->setDate(QString::fromStdString(file_name.substr(0, 10)));
        ui->listWidget->addItem(item);
        ui->listWidget->setItemWidget(item, journal);
        pos ++;
    }
}

void MainWindow::on_refreshButton_clicked()
{
    ui->listWidget->clear();
    pos = 1;
    this->showJournals();
}
