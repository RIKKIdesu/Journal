#ifndef CREATEPAGE_H
#define CREATEPAGE_H

#include "mainwindow.h"

#include <QMainWindow>
#include <QWidget>

namespace Ui {
class CreatePage;
}

class CreatePage : public QWidget
{
    Q_OBJECT

public:
    explicit CreatePage(MainWindow *home, QWidget *parent = nullptr);
    ~CreatePage();

private slots:
    void on_backButton_clicked();

    void on_spaceButton_clicked();

    void on_publishButton_clicked();

private:
    Ui::CreatePage *ui;
    MainWindow *home_page;

    void setBackground();
    void showProfilePhoto();
    void setButtonIcon();
    void setFont(QFont f);
    void setSize(int size);
    void setTextEdit();
};

#endif // CREATEPAGE_H
