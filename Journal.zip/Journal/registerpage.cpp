#include "registerpage.h"
#include "ui_registerpage.h"
#include <QMessageBox>
#include <qstring.h>
#include <iostream>
#include <unistd.h>
#include <fstream>

RegisterPage::RegisterPage(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::RegisterPage)
{
    ui->setupUi(this);
    ui->centralwidget->setStyleSheet("#centralwidget{border-image:url(:/new/prefix1/bg.png)}");
}

RegisterPage::~RegisterPage()
{
    delete ui;
}

void RegisterPage::on_Register_clicked()
{
    std::string file = setup::DataFilePath + "/users.txt";
    QString Username = ui->UsernameLine->text();
    QString Password = ui->PasswordLine1->text();
    QString cPassword = ui->PasswordLine2->text();
    if(Username == QString() || Password == QString() || cPassword == QString()){
        QMessageBox::information(this,tr("出错啦!"),"请输入用户名和密码!");
        return;
    }
    if(Password != cPassword){
        QMessageBox::information(this,tr("出错啦!"),"两次输入的密码不匹配!");
        return;
    }
    std::string name=Username.toStdString(), s_name, s_pass;
    //查找用户名
    std::ifstream f2(file);
    if(f2.fail()){
        std::ofstream outfile(file);
        outfile << "USERS:" << " " << "PASSWORDS:" <<std::endl;
        outfile.close();
    }
    while(f2>>s_name>>s_pass){
        if (s_name==name){
            QMessageBox::information(this,tr("出错啦!"),"该用户名已被注册!");
            return;
        }
    }
    std::ofstream f1(file,std::ios::app);
    f1<<name<<' '<<Password.toStdString()<<std::endl;
    QMessageBox::information(this,tr("提示"),"注册成功!");
    return;
}

