#include "myspace.h"
#include "ui_myspace.h"
#include "journalitem.h"

#include <QDir>

MySpace::MySpace(MainWindow *home, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MySpace),
    home_page(home)
{
    ui->setupUi(this);
    this->setWindowTitle("我的空间");
    setBackground();
    setButtonIcon();
    showProfilePhoto();
    showJournals();

    QTextCursor cursor = ui->userName->textCursor();
    QTextBlockFormat blockFormat;
    blockFormat.setAlignment(Qt::AlignCenter);
    cursor.setBlockFormat(blockFormat);
    cursor.insertText(QString::fromStdString(home_page->user_name));
    ui->userName->setTextCursor(cursor);
}

MySpace::~MySpace()
{
    delete ui;
}

void MySpace::showProfilePhoto()
{
    QGraphicsScene *scene = new QGraphicsScene;
    QPixmap pix;
    pix.load(QString::fromStdString(home_page->path+"profile_photos/"+home_page->user_name+".jpg"));
    scene->addPixmap(pix.scaled(200, 200));
    ui->ProfilePhoto->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->ProfilePhoto->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->ProfilePhoto->setScene(scene);
    ui->ProfilePhoto->show();
}

void MySpace::setBackground()
{
    QPalette pa(this->palette());
    QImage background = QImage(":/background/background.png");
    background = background.scaled(this->size());
    QBrush* bg = new QBrush(background);
    pa.setBrush(QPalette::Window, * bg);
    this->setPalette(pa);
}

void MySpace::setButtonIcon()
{
    QIcon icon;

    icon.addFile(":/icon/icon4.png");
    ui->backButton->setIcon(icon);
    ui->backButton->setIconSize(QSize(110, 110));
}

void MySpace::on_backButton_clicked()
{
    this->home_page->show();
    this->deleteLater();
}

void MySpace::showJournals()
{
    QListWidgetItem *item;
    JournalItem *journal;
    QDir dir(QString::fromStdString(home_page->path+"journals"));
    QFileInfoList list = dir.entryInfoList(QDir::NoDotAndDotDot | QDir::AllEntries);
    int cnt = 0;
    while ((pos <= list.size()) && (cnt < 4))
    {
        QFile file(list.at(list.size()-pos).filePath());
        std::string file_name = list.at(list.size()-pos).fileName().toStdString();
        if (file_name.substr(14, file_name.size()-18) == home_page->user_name)
        {
            item = new QListWidgetItem;
            journal = new JournalItem(this);
            item->setSizeHint(QSize(0, 300));
            file.open(QIODevice::ReadOnly | QIODevice::Text);
            QString content = file.readAll();
            journal->setText(content);
            journal->setProfile(home_page->path, file_name.substr(14, file_name.size()-18));
            journal->setDate(QString::fromStdString(file_name.substr(0, 10)));
            ui->listWidget->addItem(item);
            ui->listWidget->setItemWidget(item, journal);
            cnt ++;
        }
        pos ++;
    }
}
